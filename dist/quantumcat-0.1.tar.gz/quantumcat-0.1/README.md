# Quantum Cat

A cross platform high-level quantum computing library so that you could concentrate on building Quantum applications faster.